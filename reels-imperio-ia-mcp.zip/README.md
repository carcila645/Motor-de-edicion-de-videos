# Reels Imperio IA · Publicidi Ads — MCP

Tu propio "invideo": un servidor **MCP** que crea reels con la marca de la comunidad y entrega un MP4.
Tus usuarios lo agregan como conector (igual que agregarían el MCP de invideo), pero este es **tuyo**.

- Comunidad: **Imperio IA** — skool.com/imperio-ia-5962
- Estudio: **Publicidi Ads** — publicidads.com.co
- Motor de animación: kit de **Viegas Estudio** (ver `CREDITOS.md` y **`LICENCIA-Y-USO.md` — léelo antes de subirlo público**).

## Qué hace
Expone 3 herramientas por MCP:
| Herramienta | Qué hace |
|---|---|
| `listar_plantillas` | catálogo de plantillas (26 nichos, 64 de lanzamiento, 23 escenas 3D) con su id |
| `crear_reel` | crea el reel desde una plantilla + tus textos, tu tema de marca y el formato, y devuelve el MP4 |
| `estado_equipo` | comprueba que la máquina tiene Node, ffmpeg, Python y Chrome para renderizar |

## Estructura
```
reels-imperio-ia-mcp/
├─ mcp-server/        ← tu servidor MCP (Node)         ·  esto es TUYO
├─ pack/             ← el pack de skills + el motor     ·  motor de Viegas Estudio
├─ EMPIEZA-AQUI.html  ← página de bienvenida de la marca
├─ CREDITOS.md
└─ LICENCIA-Y-USO.md  ← léelo antes de hacerlo público
```

## Arranque rápido (local — sin alojar nada)
Cada miembro clona el repo y lo agrega a su Claude Code. Renderiza en su propia máquina.
```bash
cd mcp-server
npm install
# 1) que el motor esté listo (instala Chrome/ffmpeg la primera vez)
python3 ../pack/skills/reels-imperio-ia/scripts/preparar.py --instalar --prueba
# 2) agregar el MCP a Claude Code
claude mcp add --scope user reels-imperio-ia -- node "$(pwd)/index.mjs"
```
Luego, en Claude: *«lista las plantillas de reels-imperio-ia y hazme un gen-intro-logo con el texto …»*.

## Alojarlo (remoto — una URL para toda tu comunidad, como invideo)
En un servidor con Node + Chrome + ffmpeg (un VPS basta):
```bash
cd mcp-server && npm install
MODO=http PORT=8787 PUBLIC_URL=https://cdn.tudominio.com node index.mjs
# queda en http://TU_SERVIDOR:8787/mcp  (ponlo detrás de HTTPS)
```
Tus usuarios lo agregan igual que el de invideo:
```bash
claude mcp add --transport http --scope user reels-imperio-ia https://TU_DOMINIO/mcp
```
> Para entregar el MP4 por web necesitas servir la carpeta `trabajo/` y poner su base en `PUBLIC_URL`. Sin eso, `crear_reel` devuelve la ruta local del archivo.

## Variables de entorno
`PACK_DIR` (ruta al motor, por defecto `../pack/skills/reels-imperio-ia`) · `TRABAJO` (salida) · `PORT` · `PUBLIC_URL` · `PYTHON`.
